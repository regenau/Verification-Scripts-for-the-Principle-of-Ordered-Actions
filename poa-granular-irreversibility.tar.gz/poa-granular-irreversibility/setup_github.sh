#!/usr/bin/env bash
# ============================================================================
# setup_github.sh — Initialise and push the poa-granular-irreversibility repo
# ============================================================================
#
# Prerequisites:
#   1. git installed and configured (git config user.name / user.email)
#   2. GitHub CLI (gh) installed and authenticated, OR a GitHub personal
#      access token configured for HTTPS push
#   3. Edit GITHUB_USER below to your GitHub username or organisation
#
# Usage:
#   cd poa-granular-irreversibility/
#   chmod +x setup_github.sh
#   ./setup_github.sh
#
# ============================================================================

set -euo pipefail

# ── Configuration ──────────────────────────────────────────────────────────
GITHUB_USER="YOURUSERNAME"          # ← EDIT THIS
REPO_NAME="poa-granular-irreversibility"
DESCRIPTION="Companion code: The Principle of Ordered Action (Nicot & Regenauer-Lieb, 2026, Phil. Trans. R. Soc. A)"
# ───────────────────────────────────────────────────────────────────────────

echo "=== Step 1: Initialise local git repository ==="
git init
git add LICENSE README.md CITATION.cff .gitignore four_grain_poa.py
git commit -m "Initial release v1.0.0

Companion code for:
  Nicot F. & Regenauer-Lieb K. (2026)
  The Principle of Ordered Action: Contact Topology, Phase-Space
  Expansion, and the Arrow of Time in Granular Matter
  Phil. Trans. R. Soc. A

Contents:
  - four_grain_poa.py: two-tier irreversibility demonstration
    (3-grain and 4-grain assemblies, parity sweep N=1..7,
     phase-space integration, 12-panel publication figure)
  - BSD-3-Clause license
  - CITATION.cff for machine-readable citation"

git tag -a v1.0.0 -m "Release v1.0.0 — initial public release"

echo ""
echo "=== Step 2: Create GitHub repository ==="
echo ""
echo "Option A — Using GitHub CLI (recommended):"
echo "  gh repo create ${GITHUB_USER}/${REPO_NAME} \\"
echo "    --public \\"
echo "    --description \"${DESCRIPTION}\" \\"
echo "    --source . \\"
echo "    --remote origin \\"
echo "    --push"
echo ""
echo "Option B — Manual (if gh is not installed):"
echo "  1. Go to https://github.com/new"
echo "  2. Repository name: ${REPO_NAME}"
echo "  3. Description: ${DESCRIPTION}"
echo "  4. Public, no README/license/gitignore (we have them)"
echo "  5. Create repository, then run:"
echo ""
echo "    git remote add origin https://github.com/${GITHUB_USER}/${REPO_NAME}.git"
echo "    git branch -M main"
echo "    git push -u origin main"
echo "    git push origin v1.0.0"
echo ""

# Uncomment the block below to execute Option A automatically:
# gh repo create "${GITHUB_USER}/${REPO_NAME}" \
#   --public \
#   --description "${DESCRIPTION}" \
#   --source . \
#   --remote origin \
#   --push
# git push origin v1.0.0

echo "=== Done ==="
echo ""
echo "After pushing, visit:"
echo "  https://github.com/${GITHUB_USER}/${REPO_NAME}"
echo ""
echo "To create a release with the figure attached:"
echo "  python four_grain_poa.py"
echo "  gh release create v1.0.0 four_grain_two_tier.pdf four_grain_two_tier.png \\"
echo "    --title 'v1.0.0 — Initial release' \\"
echo "    --notes 'Companion code and Figure 6 for the PoA paper.'"
